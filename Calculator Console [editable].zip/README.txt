Please edit the run-calc on line 5 :
  cd c:\users\user\downloads\c-sharp
remove c-sharp path.
MAKE SURE YOU HAVE INSTALLED .NET 7.0-rc1

- From Developer, RegWin11, PlyJavaLTE19, TheRoleplayLlama